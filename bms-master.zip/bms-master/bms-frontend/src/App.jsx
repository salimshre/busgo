
function App() {

  return (
    <>
      <h1 className="text-center text-4xl mt-10 underline">Welcome to BookMyScreen</h1>
    </>
  )
}

export default App
